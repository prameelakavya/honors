#!/usr/bin/python

def max(a, b):
	if a > b:
		return a
	return b

if __name__=="__main__":
	f = open('./brown/cats.txt')
	text = f.read()
	f.close()
	classes = {}
	text = text.split('\n')
	text.remove('')
	for i in text:
		j = i.split(' ')
		if j[1] in classes:
			classes[j[1]].append(j[0])
		else:
			classes[j[1]] = []
			classes[j[1]].append(j[0])

	# creating pie, A, B ----> HMM Parameters
	pie = {}
	A = {}
	B = {}
	ft = open('test_data.txt', 'w')
	for i in classes:
		length = len(classes[i])
		train = (length*8)/10
		cnt = 0
		for j in classes[i]:
			if(cnt > train):
				break
			cnt += 1
			fd = open("./brown/" + j)
			text = fd.read()
			fd.close()
			text = text.split('\n')
			for u in range(len(text)):
				text[u] = text[u].strip()
			for u in text:
				if u == '':
					text.remove('')

			for k in text:
				l = k.split(' ')
				for v in l:
					if v == '':
						l.remove('')
				if len(l) == 0:
					continue
				word = l[0]
				word = word.split('/')
				if word[1] in pie:
					pie[word[1]] = pie[word[1]] + 1
				else:
					pie[word[1]] = 1

				if word[1] in B:
					if word[0] in B[word[1]]:
						B[word[1]][word[0]] += 1
					else:
						B[word[1]][word[0]] = 1
				else:
					B[word[1]] = {}
					B[word[1]][word[0]] = 1 

				if len(l) == 1:
					continue
				for m in range(len(l)-1):
					w1 = l[m]
					w2 = l[m+1]
					w1 = w1.split('/')[1]
					w2 = w2.split('/')[1]
					if w1 in A:
						if w2 in A[w1]:
							A[w1][w2] += 1
						else:
							A[w1][w2] = 1
					else:
						A[w1] = {}
						A[w1][w2] = 1

		# pre-processing for testing

		for j in classes[i][train+1:]:
			fdt = open('./brown/' + j)
			text = fdt.read()
			fdt.close()
			text = text.split('\n')
			for u in range(len(text)):
				text[u] = text[u].strip()
			for u in text:
				if u == '':
					text.remove(u)
			for u in text:
				s = ""
				l = u.split(' ')
				for v in l:
					if v == '':
						l.remove('')
				if len(l) == 0:
					continue
				for v in range(len(l)-1):
					s += l[v].split('/')[0]
					s += ' '
				s += l[len(l)-1].split('/')[0]
				ft.write(s)
				ft.write('\n')
	ft.close()

	ft = open('test_data.txt')
	text = ft.read()
	text = text.split('\n')
	for u in range(len(text)):
		text[u] = text[u].strip()
	for u in text:
		if u == '':
			text.remove('')
	# viterbi algorithm
	tags = {}
	pie_tot = 0
	for key in pie:
		pie_tot += pie[key]
	for key in pie:
		pie[key] = float(pie[key])/float(pie_tot)
	for key in B:
		cnt = 0
		for obs in B[key]:
			cnt += B[key][obs]
		for obs in B[key]:
			B[key][obs] = float(B[key][obs])/float(cnt)
	for key in A:
		cnt = 0
		for ntag in A[key]:
			cnt += A[key][ntag]
		for ntag in A[key]:
			A[key][ntag] = float(A[key][ntag])/float(cnt)
	rows = 0
	for tag in B:
		tags[rows] = tag
		rows += 1
	for i in text:
		delta = []
		sigh = []
		l = i.split(' ')
		for u in l:
			if u == '':
				l.remove('')
		cols = len(l)
		if cols == 0:
			print "empty sentence!!"
			continue
		for m in range(rows):
			temp = []
			for n in range(cols):
				temp.append(0)
			delta.append(temp)
			sigh.append(temp)
		
		for m in range(rows):
			if tags[m] not in pie:
				delta[m][0] = 0
			else:
				if l[0] not in B[tags[m]]:
					delta[m][0] = 0
				else:
					delta[m][0] = pie[tags[m]] * B[tags[m]][l[0]]
		
		for n in range(cols):
			if n == 0:
				continue
			else:
				for k in range(rows):
					max_val = 0
					prev_max = 0
					max_tag = 0
					for m in range(rows):
						prev_max = max_val
						if (tags[m] not in A) or (tags[k] not in A[tags[m]]):
							max_val = max(max_val, 0)
						else:
							max_val = max(max_val, delta[m][n-1] * A[tags[m]][tags[k]])
						if max_val > prev_max:
							max_tag = m
					if l[n] in B[tags[k]]:
						delta[k][n] = max_val * B[tags[k]][l[n]]
					sigh[k][n] = max_tag
		print l
		print sigh
		tag_seq = []
		max_val = 0
		max_tag = 0
		for m in range(rows):
			if max_val < delta[m][cols-1]:
				max_val = delta[m][cols-1]
				max_tag = m
		tag_seq.append(tags[max_tag])

		for n in range(cols):
			tag_seq.append(tags[sigh[max_tag][cols-1-n]])
			max_tag = sigh[max_tag][cols-1-n]
		tag_seq.reverse()
		print tag_seq

			













	'''f = open('token-tag.txt', 'w')
	for i in ans:
		f.write(i)
		f.write('\n')
	f.close()'''